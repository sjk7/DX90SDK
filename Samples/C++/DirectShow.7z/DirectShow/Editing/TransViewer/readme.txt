//-----------------------------------------------------------------------------
// Name: DirectShow Editing Sample - Transition Previewer
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------

Description
===========

This MFC application allows you to preview all of the 
DirectShow Editing Services transitions installed on your system.

You can preview transitions using media files or simple solid colors.
