//============================================================================
//
//  Microsoft Windows Media Technology
//  Copyright (C) Microsoft Corporation, .  All Rights Reserved.
//
//  File:        wmsdk.h
//
//  Description: WMSDK global include file
//
//============================================================================

#include "wmsdkidl.h"
#include "asferr.h"
