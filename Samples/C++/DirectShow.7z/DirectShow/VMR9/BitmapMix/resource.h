//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by bmpMix9.rc
//
#define IDD_BMPMIX9_DIALOG              101
#define IDD_ABOUTBOX                    102
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_BMPMIX9                     107
#define IDI_SMALL                       108
#define IDC_BMPMIX9                     109
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     130
#define IDB_BITMAP2                     132
#define IDB_BITMAP3                     133
#define IDM_FILE_CLOSE                  134
#define IDM_PLAY_FILE                   32771
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
