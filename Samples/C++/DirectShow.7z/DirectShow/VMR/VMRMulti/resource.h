//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDC_ADD                         3
#define IDD_VMR_MULTI                   101
#define IDB_PLAY                        102
#define IDB_STOP                        103
#define IDB_EJECT                       104
#define IDB_SWITCH                      105
#define IDI_ICON                        106
#define IDC_SLIDER                      1000
#define IDC_PLAY                        1001
#define IDC_STOP                        1002
#define IDC_EJECT                       1003
#define IDC_ACTIVE_PB                   1004
#define IDC_STATUS                      1005
#define IDC_SWITCH                      1006
#define IDC_TRANSITIONS                 1007
#define IDC_BUTTON_DELETE               1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        107
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
