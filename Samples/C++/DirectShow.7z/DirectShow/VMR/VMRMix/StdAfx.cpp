//------------------------------------------------------------------------------
// File: stdafx.cpp 
//
// Desc: DirectShow sample code
//      
//       VMRMix.pch will be the pre-compiled header
//       stdafx.obj will contain the pre-compiled type information
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------

#include "stdafx.h"



