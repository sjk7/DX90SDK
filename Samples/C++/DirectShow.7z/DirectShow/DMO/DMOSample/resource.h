
#define IDR_SAMPLE                      101

