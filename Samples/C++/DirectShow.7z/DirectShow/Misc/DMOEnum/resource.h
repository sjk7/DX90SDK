//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DMOEnum.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DMOENUM_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_LIST_DEVICES                1000
#define IDC_CHECK_SHOWALL               1001
#define IDC_LIST_FILTERS                1002
#define IDC_STATIC_CLASSES              1003
#define IDC_STATIC_FILTERS              1004
#define IDC_CHECK_KEYED                 1005
#define IDC_STATIC_FILENAME             1006
#define IDC_LIST_INPUT_TYPES            1007
#define IDC_LIST_OUTPUT_TYPES           1008
#define IDC_STATIC_NUM_ITYPES           1009
#define IDC_LIST_INPUT_STREAMS          1010
#define IDC_LIST_OUTPUT_STREAMS         1011
#define IDC_STATIC_NUM_OTYPES           1012
#define IDC_STATIC_INPUT_STREAMS        1013
#define IDC_STATIC_OUTPUT_STREAMS       1014
#define IDC_STATIC_MAXLATENCY           1015
#define IDC_CHECK_IN_WHOLE_SAMPLES      1016
#define IDC_CHECK_IN_ONESAMPLE          1017
#define IDC_CHECK_IN_HOLDSBUFFERS       1018
#define IDC_CHECK_IN_FIXED              1019
#define IDC_CHECK_OUT_WHOLE_SAMPLES     1020
#define IDC_CHECK_OUT_ONESAMPLE         1021
#define IDC_CHECK_OUT_DISCARDABLE       1022
#define IDC_CHECK_OUT_FIXED             1023
#define IDC_CHECK_OUT_OPTIONAL          1024
#define IDC_STATIC_IN_MINBUFFERSIZE     1025
#define IDC_STATIC_IN_ALIGNMENT         1026
#define IDC_STATIC_IN_MAXLOOKAHEAD      1027
#define IDC_STATIC_OUT_MINBUFFERSIZE    1028
#define IDC_STATIC_OUT_ALIGNMENT        1029
#define IDC_STATIC_IN_TYPE              1030
#define IDC_STATIC_OUT_TYPE             1031
#define IDC_CHECK_IN_SUPPORTS_QC        1032
#define IDC_CHECK_OUT_SUPPORTS_QC       1033
#define IDC_STATIC_IN_SUBTYPE           1034
#define IDC_STATIC_OUT_SUBYTPE          1035
#define IDC_STATIC_IN_FORMAT            1036
#define IDC_STATIC_OUT_FORMAT           1037
#define IDC_STATIC_IN_MINBUFFERSIZE2    1038

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
