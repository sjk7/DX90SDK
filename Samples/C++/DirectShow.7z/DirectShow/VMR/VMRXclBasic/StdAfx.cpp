//------------------------------------------------------------------------------
// File: stdafx.cpp
//
// Desc: DirectShow sample code - a simple full screen video playback sample.
//       Using the Windows XP Video Mixing Renderer, a video is played back in
//       a full screen exclusive mode.
//      
//       stdafx.cpp : source file that includes just the standard includes
//       VMRXclBasic.pch will be the pre-compiled header
//       stdafx.obj will contain the pre-compiled type information
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------


#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
