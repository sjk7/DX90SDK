//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GargleDMO.rc
//
#define IDS_PROJNAME                    100
#define IDR_GARGLE                      101
#define IDR_GARGPROP                    102
#define IDS_TITLEGargDMOProp            103
#define IDS_HELPFILEGargDMOProp         104
#define IDS_DOCSTRINGGargDMOProp        105
#define IDR_GARGDMOPROP                 106
#define IDD_GARGDMOPROP                 107

#define IDC_RADIO_SIN                   205
#define IDC_RADIO_TRIANGLE              206
#define IDC_RADIO_SQUARE                224
#define IDC_EDIT_Rate                   222
#define IDC_SLIDER_Rate                 223

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         201
#define _APS_NEXT_SYMED_VALUE           108
#endif
#endif
