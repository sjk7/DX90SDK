//-----------------------------------------------------------------------------
// Name: DirectShow Sample -- RenderLog
// 
// Copyright (c) Microsoft Corporation. All rights reserved.
//-----------------------------------------------------------------------------

Description
===========

This sample demonstrates an application's ability to create a
text log of DirectShow's progress while rendering a media file.
If you receive an error when calling RenderFile(), you can use
the RenderLog tool to create and view the render log.

