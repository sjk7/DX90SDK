//------------------------------------------------------------------------------
// File: stdafx.cpp 
//
// Desc: DirectShow sample code - source file that includes the standard includes
//      
//       vmr9allocator.pch will be the precompiled header
//       stdafx.obj will contain the pre-compiled type information
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------

#include "stdafx.h"

// TODO: reference any additional headers you need in STDAFX.H
// and not in this file
