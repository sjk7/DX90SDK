//------------------------------------------------------------------------------
// File: Stdafx.cpp
//
// Desc: DirectShow sample code
//       Stdafx.cpp : source file that includes just the standard includes
//	     stdafx.obj will contain the pre-compiled type information
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------

#include "stdafx.h"

