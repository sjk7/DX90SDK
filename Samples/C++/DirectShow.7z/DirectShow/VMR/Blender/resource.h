//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Blender.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_BLENDER_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDI_BLENDER                     129
#define IDC_BUTTON_STREAM1              1000
#define IDC_STATIC_STREAM1              1001
#define IDC_BUTTON_STREAM2              1002
#define IDC_STATIC_STREAM2              1003
#define IDC_SCREEN                      1004
#define IDC_PLAY                        1005
#define IDC_STOP                        1006
#define IDC_PAUSE                       1007
#define IDC_SLIDER_X                    1008
#define IDC_SLIDER_WIDTH                1009
#define IDC_SLIDER_Y                    1010
#define IDC_SLIDER_HEIGHT               1011
#define IDC_SLIDER_ALPHA                1012
#define IDC_SLIDER_X2                   1013
#define IDC_SLIDER_WIDTH2               1014
#define IDC_SLIDER_Y2                   1015
#define IDC_SLIDER_HEIGHT2              1016
#define IDC_SLIDER_ALPHA2               1017
#define IDC_CHECK_FLIP                  1018
#define IDC_STATIC_DURATION             1019
#define IDC_DURATION                    1020
#define IDC_STATIC_DURATION2            1021
#define IDC_DURATION2                   1022
#define IDC_POSITION                    1023
#define IDC_STATIC_GROUP1               1024
#define IDC_STATIC_GROUP2               1025
#define IDC_CHECK_MIRROR                1026
#define IDC_CHECK_FLIP2                 1027
#define IDC_CHECK_MIRROR2               1028
#define IDC_STATIC_ALPHA                1029
#define IDC_STATIC_ALPHA2               1030
#define IDC_BUTTON_ABOUT                1031

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
