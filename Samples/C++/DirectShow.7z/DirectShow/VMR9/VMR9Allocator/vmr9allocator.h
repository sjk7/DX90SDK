//------------------------------------------------------------------------------
// File: VMR9Allocator.h
//
// Desc: DirectShow sample code - Header for VMR9Allocator sample
//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//------------------------------------------------------------------------------

#if !defined(AFX_ALLOCATOR9_H__CA30736C_ACAF_4108_A46A_0E8854AF657B__INCLUDED_)
#define AFX_ALLOCATOR9_H__CA30736C_ACAF_4108_A46A_0E8854AF657B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"


#endif // !defined(AFX_ALLOCATOR9_H__CA30736C_ACAF_4108_A46A_0E8854AF657B__INCLUDED_)
