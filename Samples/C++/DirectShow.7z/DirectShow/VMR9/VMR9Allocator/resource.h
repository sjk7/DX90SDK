//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by vmr9allocator.rc
//
#define IDC_MYICON                      2
#define IDD_ALLOCATOR9_DIALOG           101
#define IDD_ABOUTBOX                    102
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_ALLOCATOR9                  107
#define IDI_SMALL                       108
#define IDC_ALLOCATOR9                  109
#define IDR_MAINFRAME                   128
#define ID_FILE_CLOSE                   134
#define IDM_PLAY_FILE                   32771
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32772
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
