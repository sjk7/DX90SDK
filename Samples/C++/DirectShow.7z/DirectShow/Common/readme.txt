This directory contains useful functions that are used by several 
of the DirectShow samples.