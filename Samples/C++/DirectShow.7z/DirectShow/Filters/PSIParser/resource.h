//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PsiParser.rc
//

#define IDD_PROGDIALOG                  104
#define IDS_TITLE                       1004
#define IDC_PROGLIST                    1027
#define IDC_VIEWBUTTON                  1028
#define IDC_StreamIdEDIT                1029
#define IDC_PatVersionEDIT              1030
#define IDC_StreamIdText                1031
#define IDC_PatVersionTEXT              1032
#define IDC_REFRESHBUTTON               1033
#define IDC_STOPBUTTON                  1034
#define IDC_ES_TEXT                     1035
#define IDC_ES_LIST                     1036
#define IDC_PROG_TEXT                   1037
#define IDC_EDIT_AUDIO                  1040
#define IDC_EDIT_VIDEO                  1041
#define IDC_AUDIO_PID                   1042
#define IDC_VIDEO_PID                   1043
#define VERSION_RES_CHARSET             1252
#define ID_DISPLAYES                    1253

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
